def D2B(k):
   l1=[]
   a=int(k)
   while a>=1:
      d=a%2
     
      l1.append(d)
      a=a//2
      z=""
   for i in l1[::-1]:
      z=z+str(i)
   print(" ",z,end="")


def B2D(a):
   l=len(a)
   c=0
   d=[] #1110
   f=l-1
   for i in a:
      d.append((2**(f))*int(i))
      f=f-1
   print(sum(d))

def H2D(a):
   dic={"A":10,"B":11,"C":12,"D":13,"E":14,"F":15}
   l=len(a)
   c=0
   d=[] #85A2
   f=l-1
   for i in a:
      if i.isdigit():
         d.append((16**(f))*int(i))
         f=f-1
      else:
         for j in dic:
            if i==j:
               k=dic.get("{}".format(i))
               d.append((16**(f)*k))
               f=f-1
            else:
               pass
               
         
   print(sum(d))

def D2H(k):
   l1=[]
   a=int(k)
   while a>=1:
      d=a%16
     
      l1.append(d)
      a=a//16
      z=""
   for i in l1[::-1]:
      z=z+str(i)
   print(" ",z,end="")




   

def D2O(a):
   l1=[]
   
   while a>=1:
      d=a%8
     
      l1.append(d)
      a=a//8
      z=""
   for i in l1[::-1]:
      z=z+str(i)
   print(" ",z,end="")

def O2D(a):
   
   l=len(a)
   
   c=0
   d=[] #85A2
   f=l-1
   for i in a:
      if i.isdigit():
         d.append((8**(f))*int(i))
         f=f-1
                
   print(sum(d))           

def B2H(a):
   
   l=len(a)
   c=0
   d=[] #85A2
   f=l-1
   for i in a:
      if f<0:
         break
      else:
         d.append((2**(f))*int(i))
         f=f-1
   Sum=sum(d)
   v=str(Sum)
   y=D2H(v)
   



def H2B():
      print("Enter the binary bits in pair of FOUR from left to right, ")
      a=input("if the leftmost bit is not paired, append it by 0 to make it paired").split()
      dic={"0000":"0",
           "0000":"0",
           "0001":"1",
           "0010":"2",
           "0011":"3",
           "0100":"4",
           "0101":"5",
           "0110":"6",
           "0111":"7",
           "1000":"8",
           "1001":"9",
           "1010":"A",
           "1011":"B",
           "1100":"C",
           "1101":"D",
           "1110":"E",
           "1111":"F",}
      for i in a:
          for j in dic:
              if i==j:
                  print(dic.get(j),end="")

def B2O():
    print("Enter the binary bits in pair of THREE from left to right, ")
    a=input("if the leftmost bit is not paired, append it by 0 to make it paired").split()
    dic={"000":"0",
         "001":"1",
         "010":"2",
         "011":"3",
         "100":"4",
         "101":"5",
         "110":"6",
         "111":"7",}
    for i in a:
       for j in dic:
          if i==j:
             print(dic.get(j),end="")

def O2B():
   a=input("Enter the number to continue the operation: ")
   l=[]
   for i in a:
      l.append(int(i))
   dic={"0":"000",
          "1":"001",
          "2":"010",
          "3":"011",
          "4":"100",
          "5":"101",
          "6":"110",
          "7":"111",}
   for i in l:
        for j in dic:
           if str(i)==j:
              print(dic.get(j),end=" ")


def H2O():
      a=(input())
      dic={
           "0":"0000",
           "1":"0001",
           "2":"0010",
           "3":"0011",
           "4":"0100",
           "5":"0101",
           "6":"0110",
           "7":"0111",
           "8":"1000",
           "9":"1001",
           "A":"1010",
           "B":"1011",
           "C":"1100",
           "D":"1101",
           "E":"1110",
           "F":"1111"}
      s=""
      for i in a:
          for j in dic:
              if i==j:
               y=dic.get(j)
               s=s+y
      h=len(s)
      o=[]
      r=""
      if h%3==0:
        for i in range(0,h,3):
            r(s[i]+s[i+1]+s[i+2])
            o.append(r)
      elif h%3==2:
            s="0"+s
            for i in range(0,h,3):
                r=(s[i]+s[i+1]+s[i+2])
                o.append(r)
      else:
            s="00"+s
            for i in range(0,h,3):
                r=(s[i]+s[i+1]+s[i+2])
                o.append(r)
         
      dic={"000":"0",
             "001":"1",
             "010":"2",
             "011":"3",
             "100":"4",
             "101":"5",
             "110":"6",
             "111":"7"}
      for i in o:
            for j in dic:
                if i==j:
                    print(dic.get(j),end="")
        
            
          
        
def O2H():
  a=input("Enter the Octal number: ")
  dic={"0":"000",
       "1":"001",
       "2":"010",
       "3":"011",
       "4":"100",
       "5":"101",
       "6":"110",
       "7":"111",}
  u=[]
  for i in a:
     for j in dic:
        if i==j:
           r=(dic.get(j))
           u.append(r)
        else:
            pass
  print("u",u)
  t=[]
  for i in u:
     if len(i)!=4:
        i="0"+i
        t.append(i)
  print(t)
  dicr={"0000":"0",
           "0000":"0",
           "0001":"1",
           "0010":"2",
           "0011":"3",
           "0100":"4",
           "0101":"5",
           "0110":"6",
           "0111":"7",
           "1000":"8",
           "1001":"9",
           "1010":"A",
           "1011":"B",
           "1100":"C",
           "1101":"D",
           "1110":"E",
           "1111":"F"}
  for i in t:
      for j in dicr:
            if i==j:
               print(dicr[j],end=" ")
      
         

   

print("1) Convert decimal to binary and vice-versa")
print("2) Convert decimal to hexadecimal and vice-versa")
print("3) Convert decimal to octal and vice-versa.")
print("4) Convert binary to hexadecimal and vice-versa.")
print("5) Convert binary to octal and vice-versa.")
print("6) Convert hexadecimal to octal and vice-versa.")
print("7) Convert number with radix A to radix B. Here A,B <= 36. In this case, you must take A,B as input.")

w=int(input("Enter the number of the query: "))
if w==1:
   print("1)Convert decimat to binary")
   print("2)Convert binary to decimal")
   v=int(input("Enter the query"))
   if v==1:
      k=input("Enter the number")
      D2B(k)

   elif v==2:
      a=input("Enter the number")
      B2D(a)
      
elif w==2:
   print("1)Convert decimal to hexadecimal")
   print("2)Convert hexa to decimal")
   v=int(input("Enter the query"))
   if v==1:
      k=input("Enter the number")
      D2H(k)
      

   elif v==2:
      H2D(a)
      a=input("Enter the number")
      
elif w==3:
   print("1)Convert decimal to octal")
   print("2)Convert octal to decimal")
   v=int(input("Enter the query"))
   if v==1:
      a=input("Enter the number")
      D2O(a)

   elif v==2:
      a=input("Enter the number")
      O2D(a)

elif w==4:
   print("1)Convert binary to hexadecimal")
   print("2)Convert hexadecimal to binary")
   v=int(input("Enter the query"))
   if v==1:
      a=input("Enter the number")
      B2H(a)
      

   elif v==2:
      H2B()

elif w==5:
   print("1)Convert binary to octal ")
   print("2)Convert octal to binary")
   v=int(input("Enter the query"))
   if v==1:
      B2O()

   elif v==2:
      O2B()

elif w==6:
   print("1)Convert hexadecimal to octal")
   print("2)Convert octal to hexadecimal")
   v=int(input("Enter the query"))
   if v==1:
      H2O()
   elif v==2:
      O2H()

elif w==7:
   int(input("Enter the radix of A: "))
   int(input("Enter the radix of B: "))
      
   

     
   
              
   
      
      


      
      
      




