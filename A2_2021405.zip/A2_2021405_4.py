Ash=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Student\Ash_12.txt",'r')
Brock=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Student\Brock_1000.txt",'r')
Misty=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Student\Misty_372.txt",'r')
Ram=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Student\Ram_1211.txt",'r')
John=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Student\John_1357.txt",'r')
admin=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Admin\AnswerKey.txt")
registered=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Admin\RegisteredStudents.txt","r")
Final=open(r"C:\Users\nkuma\AppData\Local\Programs\Python\Python39\A2-Q4\Admin\FinalReport.txt",'a')

A,B,M,R,J,k=[],[],[],[],[],[]
name=[]

rs=registered.read()
a=(rs.split("\n"))
b=(rs.split())

for m in b[0:len(b):2]:
   name.append(m)
      
for i in Ram:
   R.append(i.strip())
for i in Ash:
   A.append(i.strip())
for i in Brock:
   B.append(i.strip())
for i in Misty:
   M.append(i.strip())
for i in John:
   J.append(i.strip())


for j in admin:
   k.append(j.strip())
   

correct=0
neg=0

for n in range(0,20):
      if J[n]==k[n]:
          correct=correct+4
      else: 
          if "-" in J[n]:
              continue
          else:
              neg=neg+1
print(correct)
print(neg)  
score=correct-neg
t=("John 1357 {}".format(score)+"\n")
q=Final.write(t)

for n in range(0,20):

      
      if R[n]==k[n]:
          correct=correct+4
      else: 
          if "-" in R[n]:
              continue
          else:
              neg=neg+1
              
print(correct)
print(neg)  
score=correct-neg
print(score)
t=("Ram 1211 {}".format(score)+"\n")
q=Final.write(t)

for n in range(0,20):
      if B[n]==k[n]:
             correct=correct+4
      else: 
          if "-" in B[n]:
              continue
          else:
              neg=neg+1
print(correct)
print(neg)  
score=correct-neg
t=("Brock 1000 {}".format(score)+"\n")
q=Final.write(t)

for n in range(0,20):
      if M[n]==k[n]:
          correct=correct+4
      else: 
          if "-" in M[n]:
              continue
          else:
              neg=neg+1
print(correct)
print(neg)  
score=correct-neg
t=("Misty 372 {}".format(score)+"\n")
q=Final.write(t)

for n in range(0,20):  
      if A[n]==k[n]:
          correct=correct+4
      else: 
          if "-" in A[n]:
              continue
          else:
              neg=neg+1
              
print(correct)
print(neg)  
score=correct-neg
t=("Ash 12 {}".format(score)+"\n")
q=Final.write(t)







Ash.close()
Brock.close()
Misty.close()
Ram.close()
John.close()
Final.close()

admin.close()
registered.close()
