n=int(input("Enter the size of the matrix: "))
L=[]

for i in range (n):
   d=[]
   a=(input("Enter the first row. (space separated)")).split()
   for k in a:
      q=int(k)
      d.append(q)
   L.append(d)
   
print("\n")
for i in L:
   print(i)
print("\n")



l=[]
for i in L:
   for j in i:
      l.append(j)


def NT(x):
   for i in x:
      for j in i:
         print(j,end=" ")

        

def AT(L):
   q=[]
   for i in range(len(L)):
      if i%2==0:
         r=L[i]
         q.append(r)
      else:
         
         r=(L[i][::-1])
         q.append(r)
   
   print("\n")
   for i in q:
      for j in i:
         print(j, end=" ")




def BT(L):
    a=0
    b=0
    row=len(L)
    col=len(L[1])
    l=[]
    
    for i in range(a,row):
        r=L[a][i]
        l.append(r)
 
    for j in range(a+1,col):
        r=L[j][row-1]
        l.append(r)
   
    if (row-1)==i:
        for z in range(row-2,b- 1,-1):
            r=L[row-1][z]
            l.append(r)

    if ((col-1)!=b):
        for x in range(row-2,a,-1):
            r=L[x][b]
            l.append(r)
    for i in l:
       print(i,end=" ")
   
           
      
def DTrl(L):
   
    n=len(L)
    u=[]
    for i in range(n):
        a=0
        b=i
        
        while(b>=0):
            r=L[a][b]
            u.append(r)
            a+=1
            b=b-1
            
    for j in range(n):

        a=j
        b=n-1
        
        while (a<n):
            r=L[a][b]
            u.append(r)
            a+= 1
            b=b-1
    for i in u:
       print(i,end=" ")
       

def DTlr(L):
   n=len(L)
   u=[]
   for i in range(0,n,-1):
      a=0
      b=i
      
      while(b<=0):
         r=L[a][b]
         u.append(r)
         a=a-1
         b=b+1

   for j in range(n):
      a=j
      b=n-1
      while (a>n):
         r=L[a][b]
         u.append(r)
         a=a-1
         b=b+1
   print(u)




def ST(L):
    a=0
    b=0
    row=len(L)
    col=len(L[1])
    l=[]
    
    for i in range(a,row):
        r=L[a][i]
        l.append(r)
 
    for j in range(a+1,col):
        r=L[j][row-1]
        l.append(r)
   
    if (row-1)==i:
        for z in range(row-2,b- 1,-1):
            r=L[row-1][z]
            l.append(r)

    if ((col-1)!=b):
        for x in range(row-2,a,-1):
            r=L[x][b]
            l.append(r)
    for i in l:
       print(i,end=" ")

print("1) Normal traversal( from left to right for each row)")
print("2) Alternating traversal")
print("3) Spiral traversal from outer to inwards")
print("4) Boundary traversal.")
print("5) Diagonal traversal from right to left")
print("6) Diagonal traversal from left to right.")
print("\n")
f=int(input("Enter the number of the query to proceed: "))

if f==1:
   NT(L)
elif f==2:
   AT(L)
elif f==3:
   ST(L)
elif f==4:
   BT(L)
elif f==5:
  DTlr(L)
elif f==6:
   DTlr(L)
else:
   print("Invalid selection")
   









   
