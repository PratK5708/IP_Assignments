def noteCreate():
   a=open("scalemajor.txt","w")
   b=open("scaleminor.txt","w")
   l=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B","C'","C","C#","D","D#","E","F","F#","G","G#","A","A#","B","C'"]
   for i in range(12):
      
      major=[l[i+0],l[i+2],l[i+4],l[i+5],l[i+7],l[i+9],l[i+11],l[i+12]]
      minor=[l[i+0],l[i+2],l[i+3],l[i+5],l[i+7],l[i+8],l[i+10],l[i+12]]
      ma=""
      mi=""
      
      for i in major:
         ma=ma+i+" "
      ma=ma+"\n"
      d=a.write(ma)

      for j in minor:
         mi=mi+j+" "
      mi=mi+"\n"
      e=b.write(mi)
      
   a.close()
   b.close()

def majorNotes(): #root=C
   a=open("scalemajor.txt")
   b=open("scaleminor.txt")
   p=input("Enter the root note: ")
   q=input("Enter the type of scale (Major-> M | Minor-> m) : ")

   Major="M"
   Minor="m"

   if q==Major:
      a=open("scalemajor.txt","r")
      b=a.read()
      c=b.split("\n")
      for i in c:
         if i[0]==p:
            print(i)
            break
         if i[0:2]==p:
            print(i)
            break

   if q==Minor:
      a=open("scaleminor.txt","r")
      b=a.read()
      c=b.split("\n")
      for i in c:
         if i[0]==p:
            print(i)
            break
         if i[0:2]==p:
            print(i)
            break        

   a.close()

noteCreate()
majorNotes()
