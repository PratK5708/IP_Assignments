a=open("A2.txt","r")

def wordcount():
   n=input("Enter the word to find: ")
   cursor=a.read().split()
   l=[]
   number=0
   for i in cursor:
      l.append(i)
   for j in l:
      if j==n:
         number+=1
      else:
         pass
   print("Total count of {} : ".format(n),number)


def uniqueword():
   l=[]
   cursor=a.read()
   for i in cursor:
      l.append(i)
   uni=set(l)
   print(uni)


def windex():
   cursor=a.read().split()
   b=input("Find the word to search: ")
   for i in cursor:
      count=0
      if i==b:
         count+=1
      else:
         pass
   print("The index of the word %s"%b)


def replace():
   cursor=a.read().split()
   b=input("Enter the word which has to be replaced: ")
   d=input("word to be changed: ")
   q=[]
   for i in cursor:
      if i==b:
         c=cursor.index(i)
         #c=cursor.index("{}".format(b))
         cursor.remove(i)
         q.append(c)
      else:
         pass
   
   for i in q:
      cursor.insert(i,"{}".format(d))
   print(cursor)

      
      

def Exec():
   print("Enter your choice: ")
   print("1. Display specfic Word Count")
   print("2. Display all Unique Words")
   print("3. Display all Word Counts")
   print("4. Replace word")
   print("5. Quit")
   t=int(input("Enter the query number: "))
   
   if t==1:
      wordcount()
   elif t==2:
       uniqueword()
   elif t==3:
      windex()
   elif t==4:
      replace()
   elif t==5:
      print("Please run the program again to perform the queries ")
      
      
   
         


      
